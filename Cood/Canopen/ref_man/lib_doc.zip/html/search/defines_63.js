var searchData=
[
  ['co_5fattr_5fdefval',['CO_ATTR_DEFVAL',['../co__odaccess_8h.html#af6f5f64747f6cf29d96e6187ee6aed94',1,'co_odaccess.h']]],
  ['co_5fattr_5flimit',['CO_ATTR_LIMIT',['../co__odaccess_8h.html#a35a5ef4203562b9b1cd86b9896097cb2',1,'co_odaccess.h']]],
  ['co_5fattr_5fmap',['CO_ATTR_MAP',['../co__odaccess_8h.html#a9c12ae151fa285e94dc5d51293439ce8',1,'co_odaccess.h']]],
  ['co_5fattr_5fmap_5frec',['CO_ATTR_MAP_REC',['../co__odaccess_8h.html#a873d4151549a17227b77f79876040a18',1,'co_odaccess.h']]],
  ['co_5fattr_5fmap_5ftr',['CO_ATTR_MAP_TR',['../co__odaccess_8h.html#a2183e32d0859eb6e69ed0f43da0d62fb',1,'co_odaccess.h']]],
  ['co_5fattr_5fnum',['CO_ATTR_NUM',['../co__odaccess_8h.html#a93f02a11c5577f7472e6b5c910ee1ab3',1,'co_odaccess.h']]],
  ['co_5fattr_5fread',['CO_ATTR_READ',['../co__odaccess_8h.html#a8a3552d5a27446eadbd83e3d85626c8c',1,'co_odaccess.h']]],
  ['co_5fattr_5fwrite',['CO_ATTR_WRITE',['../co__odaccess_8h.html#a8e19264b8da33ebbf00413fca42f527e',1,'co_odaccess.h']]],
  ['co_5femcy_5ferrcode_5fcomm_5ferror',['CO_EMCY_ERRCODE_COMM_ERROR',['../co__emcy_8h.html#ac002d09ca1c46ee121d8e09eefb78cb3',1,'co_emcy.h']]],
  ['co_5femcy_5ferrcode_5fpdo_5flen',['CO_EMCY_ERRCODE_PDO_LEN',['../co__emcy_8h.html#a24cc74d9b5fc855dcde2f8bf45d8bbc2',1,'co_emcy.h']]],
  ['co_5fos_5flock_5fod',['CO_OS_LOCK_OD',['../co__odaccess_8h.html#a4f7bb009e2c7d78e9bab17b9c99ee5ff',1,'co_odaccess.h']]],
  ['co_5fos_5funlock_5fod',['CO_OS_UNLOCK_OD',['../co__odaccess_8h.html#a5902052d211d951aba7c988a3beafe4e',1,'co_odaccess.h']]],
  ['co_5fstore_5farea_5fall',['CO_STORE_AREA_ALL',['../co__store_8h.html#ac74079f60d0acba0cc155d63e7f2a855',1,'co_store.h']]],
  ['co_5fstore_5fsignature_5fload',['CO_STORE_SIGNATURE_LOAD',['../co__store_8h.html#a15cbb78f0491f2bdca10ecc1af13ebf1',1,'co_store.h']]],
  ['co_5fstore_5fsignature_5fsave',['CO_STORE_SIGNATURE_SAVE',['../co__store_8h.html#a93bb495f39f7a03c5efc6aec989c2908',1,'co_store.h']]]
];
