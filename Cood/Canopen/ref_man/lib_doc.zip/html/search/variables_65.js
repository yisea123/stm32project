var searchData=
[
  ['enabled',['enabled',['../struct_c_o___c_a_n___c_o_b___t.html#afacc13a903051c648062edd13c531a34',1,'CO_CAN_COB_T']]],
  ['extended',['extended',['../struct_c_o___c_a_n___c_o_b___t.html#a0a3447d1cb92cb04b98f057866f89a45',1,'CO_CAN_COB_T']]]
];
