var searchData=
[
  ['tableidx',['tableIdx',['../struct_c_o___o_b_j_e_c_t___d_e_s_c___t.html#a178749b4423f0621ee318ff611e60451',1,'CO_OBJECT_DESC_T']]],
  ['ticks',['ticks',['../structco__timer.html#adc5199b107f7fb41d5f08d98a733d271',1,'co_timer']]],
  ['transmit',['transmit',['../struct_c_o___c_a_n___c_o_b___t.html#ad2fbd558a5bce95c8f16e389694a2b48',1,'CO_CAN_COB_T']]]
];
