var searchData=
[
  ['tableidx',['tableIdx',['../struct_c_o___n_v___s_t_o_r_a_g_e.html#a178749b4423f0621ee318ff611e60451',1,'CO_NV_STORAGE']]],
  ['ticks',['ticks',['../structco__timer.html#adc5199b107f7fb41d5f08d98a733d271',1,'co_timer']]]
];
