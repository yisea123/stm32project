var searchData=
[
  ['oddescidx',['odDescIdx',['../struct_c_o___o_d___a_s_s_i_g_n___t.html#ab2ce83e1f0758e4af8a610bed2fa916b',1,'CO_OD_ASSIGN_T']]],
  ['odtype',['odType',['../struct_c_o___o_d___a_s_s_i_g_n___t.html#af629542ac68a52b6f49230e23a7d0fa5',1,'CO_OD_ASSIGN_T']]]
];
