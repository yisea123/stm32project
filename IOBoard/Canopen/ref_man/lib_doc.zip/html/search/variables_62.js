var searchData=
[
  ['bitrate',['bitRate',['../struct_c_o_d_r_v___b_t_r___t.html#ad13c029613ce518e1d267a2aeae60be7',1,'CODRV_BTR_T']]]
];
