var searchData=
[
  ['bitrate',['bitRate',['../struct_c_o_d_r_v___b_t_r___t.html#ad13c029613ce518e1d267a2aeae60be7',1,'CODRV_BTR_T']]],
  ['bool_5ft',['BOOL_T',['../co__datatype_8h.html#a551f64d2552452a93f6f3f8371d5c00c',1,'co_datatype.h']]]
];
